$(function() {
    //	区域选择部分
    var pro;
    var city;
    $(".heqy input").on("click",
    function() {
        $(".heqy .box").show();
        $(".city").hide();
        $(".town").hide();
        $(".province").css("width", "338px");
        $.ajax({
            type: "get",
            url: "js/new_city.json",
            success: function(data) {
                $.each(data,
                function(i, item) {
                    var lis = "<li data-name=" + item.text + "><span>" + item.text + "</span><b>></b></li>";
                    $(".province").append(lis);
                    $(document).on("click", ".province li",
                    function(e) {
                        if ($(this).hasClass("title")) {
                            return false;
                        }
                        var list;
                        var txt = e.target.getAttribute('data-name');
                        $(".heqy .box .province li").removeClass("orange");
                        $(this).addClass("orange");
                        $(".heqy .box .city").show();
                        pro = $(this).find("span").text();
                        $(".province").css("width", "167px");
                        if (txt == item.text) {
                            if (txt == "北京市" || txt == "上海市" || txt == "重庆市" || txt == "天津市" || txt == "深圳市" || txt == "澳门") {
                                $(".heqy .box .town").hide();
                                list = "<li class='title'>选择区（县）</li>";
                                for (var i = 0; i < item.children.length; i++) {
                                    list += "<li city-name=" + item.children[i].text + "><span>" + item.children[i].text + "</span></li>";
                                }
                            } else {
                                list = "<li class='title'>选择城市</li>";
                                for (var i = 0; i < item.children.length; i++) {
                                    list += "<li city-name=" + item.children[i].text + "><span>" + item.children[i].text + "</span><b>></b></li>";
                                }
                            }
                            $(".city").html(list);
                        }
                    });
                    $.each(item.children,
                    function(k, items) {
                        var citys = items.children;
                        $(document).on("click", "#city li",
                        function(e) {
                            if ($(this).hasClass("title")) {
                                return false;
                            }
                            $(".heqy .box .city li").removeClass("orange");
                            $(this).addClass("orange");
                            city = $(this).find("span").text();
                            var lists = "<li class='title'>选择区（县）</li>";
                            var txts = e.target.getAttribute('city-name');
                            if (txts == items.text) {
                                if (citys == undefined) {
                                    $(".heqy .box .town").hide();
                                    $(".heqy .box").hide();
                                    $(".heqy input").val(pro + " " + city);
                                    return false;
                                } else {
                                    $(".heqy .box .town").show();
                                    for (var i = 0; i < citys.length; i++) {
                                        lists += "<li>" + citys[i].text + "</li>";
                                    }
                                }
                                $(".town").html(lists);
                            }
                        });
                    });
                });
            }
        });
    });

    // 城市列表点击
    $(document).on("click", ".heqy .box .province li",
    function() {
        if ($(this).hasClass("title")) {
            return false;
        } else {
            pro = $(this).find("span").text();
            $(document).on("click", ".heqy .box .city li",
            function() {
                if ($(this).hasClass("title")) {
                    return false;
                } else {
                    city = $(this).find("span").text();
                    $(document).on("click", ".heqy .box .town li",
                    function() {
                        if ($(this).hasClass("title")) {
                            return false;
                        } else {
                            var town = $(this).text();
                            $(".heqy .box").hide();
                            $(".heqy input").val(pro + " " + city + " " + town);
                        }
                    });
                }
            });
        }
    });

    //	点击空白关闭
    $(document).on("click",
    function(e) {
        var _conss = $('.heqy');
        if (!_conss.is(e.target) && _conss.has(e.target).length === 0) {
            $(".heqy .box").hide();
        }
    });
});